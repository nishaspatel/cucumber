import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

/**
 * Created by Suhagkumar on 09/07/2017.
 */
public class Amazon
{
    public static void main(String args[])
    {
        WebDriver amazon=new FirefoxDriver();

        //open <www.amazon.co.uk> website
        amazon.get("https://www.amazon.co.uk/");
        amazon.manage().window().maximize();

        //Delete all cookies
        amazon.manage().deleteAllCookies();

        //Give time to load Page
        amazon.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);


        //Redirect user on Register page
        amazon.findElement(By.linkText("Start here.")).click();
        amazon.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);

        //Enter User Name
        amazon.findElement(By.xpath("//*[@id='ap_customer_name']")).sendKeys("nisha");

        //Enter user's Email id
        amazon.findElement(By.xpath("//*[@id='ap_email']")).sendKeys("nishatest@gamil.com");

        //Enter Password
        amazon.findElement(By.xpath("//*[@id='ap_password']")).sendKeys("Nisha123456");

        //Enter Confirm Password
        amazon.findElement(By.xpath("//*[@id='ap_password_check']")).sendKeys("nisha123456");

        //Click on Register
        amazon.findElement(By.xpath("//*[@id='a-autoid-0']")).click();


    }
}
