import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


/**
 * Created by Suhagkumar on 08/07/2017.
 */
public class Automation
{
    public static void main(String args[])
    {
        WebDriver driver=new FirefoxDriver();
        
        //driver.get("https://www.google.co.uk");
        //driver.close();
        driver.get("http://www.seleniumhq.org/");
        driver.findElement(By.id("menu_download")).click();

    }


}
