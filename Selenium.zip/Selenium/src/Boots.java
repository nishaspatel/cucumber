import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.sql.Time;
import java.util.concurrent.TimeUnit;

/**
 * Created by Suhagkumar on 11/07/2017.
 */
public class Boots
{
    public static void main(String args[])
    {
        WebDriver boots= new FirefoxDriver();

        boots.get("http://www.boots.com/");

        boots.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);

        boots.manage().window().maximize();

        boots.findElement(By.xpath(".//*[@id='signInQuickLink']/span")).click();

        boots.findElement(By.xpath(".//*[@id='WC_AccountDisplay_links_3']")).click();

        Select drpTitle=new Select(boots.findElement(By.xpath(".//*[@id='editRegistrationTitle']")));
        drpTitle.selectByVisibleText("Mrs");

        boots.findElement(By.xpath(".//*[@id='WC_UserRegistrationAddForm_NameEntryForm_FormInput_firstName_1']")).sendKeys("Nsam");

        boots.findElement(By.xpath(".//*[@id='WC_UserRegistrationAddForm_NameEntryForm_FormInput_lastName_1']")).sendKeys("Patel");

        boots.findElement(By.xpath(".//*[@id='WC_UserRegistrationAddForm_FormInput_logonId_In_Register_1_1']")).sendKeys("nisha@gmail.com");

        boots.findElement(By.xpath(".//*[@id='WC_UserRegistrationAddForm_FormInput_logonPassword_In_Register_1']")).sendKeys("Nisha232453");

        boots.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);

        boots.findElement(By.xpath(".//*[@id='WC_UserRegistrationAddForm_FormInput_logonPasswordVerify_In_Register_1']")).sendKeys("Nishajhd");

        //Enter number f Advantage Card number

        boots.findElement(By.xpath(".//*[@id='advantageCardNumber']")).sendKeys("12345689876");


        boots.findElement(By.xpath(".//*[@id='zipCode']")).sendKeys("HA38HZ");


        WebElement oCheckbox=boots.findElement(By.xpath(".//*[@id='WC_UserRegistrationAddForm_div_8']/div[11]/div/label"));
        oCheckbox.click();


        boots.findElement(By.xpath(".//*[@id='WC_UserRegistrationAddForm_links_1']/div[2]")).click();
    }
}
