import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;

/**
 * Created by Suhagkumar on 10/07/2017.
 */
public class EE
{
    public static void main(String args[])
    {
        WebDriver ee=new FirefoxDriver();

        //Open EE Website
        ee.get("http://shop.ee.co.uk/?WT.MC_ID=ON_MEC_S_MICROSOFT_G_Brand%20EE%20Only_p5915386904&WT.srch=1");

        //Window become Maximize
        ee.manage().window().maximize();

        //Give Time to Load EE PAge
        ee.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);

        //Redirect User to Login / Register Page
        ee.findElement(By.linkText("Log in / Register")).click();

        //Redirect User on Registeration Page
        ee.findElement(By.linkText("Register now >")).click();

        //Enter User First Name
        ee.findElement(By.id("capture_traditionalRegistration_traditionalRegistration_firstName")).sendKeys("Nisha");

        //Enter User Last Name
        ee.findElement(By.xpath(".//*[@id='capture_traditionalRegistration_traditionalRegistration_lastName']")).sendKeys("patel");

        //Enter User Valid Email Address
        ee.findElement(By.xpath(".//*[@id='capture_traditionalRegistration_traditionalRegistration_emailAddress']")).sendKeys("nisha@gmail.com");

        //Enter User Password
        ee.findElement(By.xpath(".//*[@id='capture_traditionalRegistration_traditionalRegistration_password']")).sendKeys("Nisha11234432");

        //User can see Password useing <SHOW>
        ee.findElement(By.xpath(".//*[@id='showPasswordtraditionalRegistration']")).click();

        //User Tick it for remembering User for EE Website
        WebElement oCheckbox=ee.findElement(By.xpath(".//*[@id='login_remember_me']"));
        oCheckbox.click();

        //User click on Register Page
        ee.findElement(By.xpath(".//*[@id='register-email-button']")).click();

        //close Window
        ee.quit();

    }
}
