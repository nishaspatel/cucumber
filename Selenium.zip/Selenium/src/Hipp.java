import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;

/**
 * Created by Suhagkumar on 11/07/2017.
 */
public class Hipp
{
    public static void main(String args[])
    {
        WebDriver Hipp=new FirefoxDriver();

        Hipp.get("https://www.hipp.co.uk/hipp-baby-club/?utm_source=bing&utm_medium=cpc&utm_campaign=Brand%202017&utm_term=hipp&utm_content=Pure%20Brand%20-%20Exact");

        Hipp.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);

        Hipp.manage().window().maximize();

        Hipp.findElement(By.xpath(".//*[@id='showme1']/ul/div[1]/li/a")).click();

        //select Title
        Select drpTitle=new Select(Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[1]/select")));
        drpTitle.selectByVisibleText("Miss");

        //User enter First Name
        Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[2]/input")).sendKeys("Nisha");

        //User enter Last Name
        Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[3]/input")).sendKeys("Patel");

        //User enter Postcode
        Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[4]/div/div[1]/div/input")).sendKeys("HA3 8HZ");

        //User enter house number/street name
        Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[4]/div/div[2]/div/input")).sendKeys("96/elmsleigh avenue");

        //User enter county name
        Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[5]/div/div[1]/div/input")).sendKeys("Middlesex");

        //User enter Town name
        Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[5]/div/div[2]/div/input")).sendKeys("Harrow");

        //User select country
        Select drpCountry=new Select(Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[6]/select")));
        drpCountry.selectByVisibleText("UK");


        //User select Baby's Birthday or Excepted delivery date
        Select drpDay=new Select(Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[7]/div/div/div/div[1]/select")));
        drpDay.selectByIndex(10);

        //Month
        Select drpMonth=new Select(Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[7]/div/div/div/div[2]/select")));
        drpMonth.selectByIndex(4);

        //Year
        Select drpYear=new Select(Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[7]/div/div/div/div[3]/select")));
        drpYear.selectByValue("2016");


//CREATE YOUR ACCOUNT
        Hipp.manage().timeouts().implicitlyWait(1000,TimeUnit.SECONDS);

        //User enter Email
        Hipp.findElement(By.xpath(".//*[@id='email']")).sendKeys("nishjaj@gmail.com");

        //User enter Email again to confirm it
        Hipp.findElement(By.xpath(".//*[@id='email_repeat']")).sendKeys("nishjaj@gmail.com");


        //User enter Password
        Hipp.findElement(By.xpath(".//*[@id='password']")).sendKeys("Nishask13243543");

        //User enter Password to confirm
        Hipp.findElement(By.xpath(".//*[@id='password2']")).sendKeys("Nishask13243543");


        //User select radio button
        WebElement radioBtn= Hipp.findElement(By.xpath(".//*[@id='gift-options-box']/label[2]"));
        radioBtn.click();


        //User select sme Question answers
        Select drpQue1=new Select(Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[20]/select")));
        drpQue1.selectByVisibleText("Free HiPP Jar Leaflet");


        Select drpQue2=new Select(Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[21]/select")));
        drpQue2.selectByVisibleText("Asda");


        Select drpQue3=new Select(Hipp.findElement(By.xpath(".//*[@id='c25']/div[2]/div/form/div[22]/select")));
        drpQue3.selectByIndex(2);


        WebElement oCheckbox=Hipp.findElement(By.xpath(".//*[@id='checkboxToc']"));
        oCheckbox.click();

        Hipp.findElement(By.xpath(".//*[@id='child-accordion']/div[3]/button")).click();
        Hipp.close();

    }
}
