import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;

/**
 * Created by Suhagkumar on 10/07/2017.
 */
public class Orangehrm
{
    public static void main(String args[])
    {
        WebDriver orangehrm = new FirefoxDriver();

        orangehrm.get("https://www.orangehrm.com/demo_form.php?type=ent-demo");
        orangehrm.manage().window().maximize();
        orangehrm.manage().deleteAllCookies();
        orangehrm.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);

        orangehrm.findElement(By.xpath("//*[@id='register-form']/div[1]/div[1]/div[1]/div/input")).sendKeys("nisha");
        orangehrm.findElement(By.xpath("//*[@id='register-form']/div[1]/div[1]/div[2]/div/input")).sendKeys("oatel");
        orangehrm.findElement(By.xpath("//*[@id='companyName']")).sendKeys("CDB");

        Select drpIndustry=new Select(orangehrm.findElement(By.name("orangeIndustry")));
        drpIndustry.selectByVisibleText("Education");

        orangehrm.findElement(By.name("orangeJobTitle")).sendKeys("Tester");

        orangehrm.findElement(By.name("orangeEmail")).sendKeys("nwjfnuegb@gmail.com");

        orangehrm.findElement(By.name("orangePhone")).sendKeys("097654323456");

        orangehrm.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);

        Select drpCountry=new Select(orangehrm.findElement(By.xpath(".//*[@id='country']")));
        drpCountry.selectByVisibleText("India");

        Select drpState=new Select(orangehrm.findElement(By.xpath(".//*[@id='state']")));                           //After select country It should me select State accrding to Selected Country,I try many time vipulbhai
       // drpState.selectByVisibleText("Gujarat");
        drpState.getFirstSelectedOption().getText();


        Select drpNoofEmployee=new Select(orangehrm.findElement(By.xpath(".//*[@id='orangeNoEmp']")));
        drpNoofEmployee.selectByValue("11 - 15 ");


//      WebElement ListBox =orangehrm.findElement(By.xpath(".//*[@id='state']"));
//      ListBox.click();







    }
}
