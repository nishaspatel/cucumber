import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.sql.Time;
import java.util.concurrent.TimeUnit;

/**
 * Created by Suhagkumar on 10/07/2017.
 */
public class TheTimes
{
    public static void main(String args[])
    {
        WebDriver thetimes=new FirefoxDriver();


        thetimes.manage().window().maximize();

        thetimes.manage().deleteAllCookies();

        thetimes.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);

        thetimes.get("https://join.thetimes.co.uk");

        //Select Your country
//                Select drpCountry=new Select(thetimes.findElement(By.id("countrySelector")));
//                drpCountry.selectByVisibleText("India");

        //Select subscribe for Register
        thetimes.findElement(By.xpath("//div[@id='a3J200000004RKBEA2']/div/div/button")).click();

        thetimes.get("https://join.thetimes.co.uk");


        thetimes.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);

         Select dropdown=new Select(thetimes.findElement(By.xpath(".//*[@id='title']")));
         dropdown.selectByVisibleText("Miss");

         //User enter First Name
        thetimes.findElement(By.xpath(".//*[@id='firstName']")).sendKeys("Nisha");

        //User enter Last Name
        thetimes.findElement(By.xpath(".//*[@id='lastName']")).sendKeys("Patel");

        //User enter email address
        thetimes.findElement(By.xpath(".//*[@id='email']")).sendKeys("nisha@gmail.com");

        //User enter Email again to confirm it
        thetimes.findElement(By.xpath(".//*[@id='confirmEmail']")).sendKeys("nisha@gmail.com");

        //User enter Password
        thetimes.findElement(By.xpath(".//*[@id='password']")).sendKeys("Nisha12345678");

        //User enter Password again to confirm it
        thetimes.findElement(By.xpath(".//*[@id='confirmPassword']")).sendKeys("Nisha1234");

        //User select Day of Birth
        Select drpDay=new Select(thetimes.findElement(By.xpath("//*[@id='dateOfBirthDay']")));
        drpDay.selectByIndex(15);

        //User select Month of Birth
        Select drpMonth=new Select(thetimes.findElement(By.xpath("//*[@id='dateOfBirthMonth']")));
        drpMonth.selectByVisibleText("May");

        //User select Year of Birth
        Select drpYear=new Select(thetimes.findElement(By.xpath("//*[@id='dateOfBirthYear']")));
        drpYear.selectByValue("1976");


        //User enter Phone number
        thetimes.findElement(By.xpath("//*[@id='phone']")).sendKeys("0987354322743");

        //Click on button
        thetimes.findElement(By.xpath(".//*[@id='accountCreationButton']")).click();



    }
}
