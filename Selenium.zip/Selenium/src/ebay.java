import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

import java.util.concurrent.TimeUnit;

/**
 * Created by Suhagkumar on 09/07/2017.
 */
public class ebay
{
    public static void main(String args[])
    {
        WebDriver ebay=new FirefoxDriver();
        ebay.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS) ;

        //Its open website
        ebay.get("https://www.ebay.co.uk/");
        ebay.manage().deleteAllCookies();
        ebay.manage().window().maximize();
        //its redirect on register page
        ebay.findElement(By.linkText("register")).click();

        //Enter First name
        ebay.findElement(By.xpath("//*[@id='firstname']")).sendKeys("nisha");

        //Enter Last Name
        ebay.findElement(By.xpath("//*[@id='lastname']")).sendKeys("patel");

        //Enter Email
        ebay.findElement(By.xpath("//*[@id='email']")).sendKeys("nihatest20@gmail.com");

        //Enter Password
        ebay.findElement(By.xpath("//*[@id='PASSWORD']")).sendKeys("Nisha123456");

        //Click on Register
        ebay.findElement(By.xpath("//*[@id='ppaFormSbtBtn']")).click();

        String expected="WANT TO JOIN AS A BUSINESS?";
        String actual= ebay.findElement(By.xpath("//div[@id='mainContent']/div/div")).getText();

        Assert.assertEquals("WANT TO JOIN AS A BUSINESS?","WANT TO JOIN AS A BUSINESS?");

    }
}
