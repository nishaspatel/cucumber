import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

/**
 * Created by Suhagkumar on 09/07/2017.
 */
public class google
{
    private static WebDriverWait wait;

    public static void main(String args[])
    {
        WebDriver driver=new FirefoxDriver();

        driver.get("https://www.google.co.uk/?gws_rd=ssl");

        //google.manage().deleteAllCookies();

        driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);

        driver.manage().window().maximize();

        driver.findElement(By.linkText("Gmail")).click();


        //wait=new WebDriverWait(driver,30);

        driver.findElement(By.linkText("CREATE AN ACCOUNT")).click();

        //driver.get("https://accounts.google.com/SignUp?service=mail&continue=https://mail.google.com/mail/?pc=topnav-about-en");

        //driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);


        driver.findElement(By.xpath("//*[@id='FirstName']")).sendKeys("nifhth");

        //WebElement elename= driver.findElement(By.xpath("//*[@id='FirstName']"));
        //elename.sendKeys("nisha");

        //driver.findElement(By.xpath(".//*[@id='FirstName']")).sendKeys("Dimple");

        driver.close();

        driver.findElement(By.xpath("//*[@id='LastName']")).sendKeys("patel");

        driver.findElement(By.xpath("//*[@id='Passwd']")).sendKeys("Nisha123456");

        driver.findElement(By.xpath("//*[@id='PasswdAgain']")).sendKeys("Nisha12345");

        Select drpBirthday=new Select(driver.findElement(By.xpath("//*[@id='BirthMonth']")));
        drpBirthday.selectByVisibleText("May");

        driver.findElement(By.xpath(".//*[@id='BirthDay']")).sendKeys("24");

        driver.findElement(By.xpath(".//*[@id='BirthYear']")).sendKeys("1877");

        Select gender=new Select(driver.findElement(By.xpath(".//*[@id='BirthYear']")));
        gender.selectByVisibleText("Female");
        driver.quit();
    }
}
