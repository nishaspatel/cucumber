import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import java.util.concurrent.TimeUnit;

/**
 * Created by Suhagkumar on 09/07/2017.
 */
public class nopCommerce
{
    public static void main(String args[])
    {
        WebDriver driver=new FirefoxDriver();

        driver.get("https://www.nopcommerce.com/");

        driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);

        driver.manage().deleteAllCookies();

        driver.findElement(By.linkText("Register")).click();

        //type First Name
        driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_txtFirstName")).sendKeys("nisha");

        //type Last Name
        driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_txtLastName")).sendKeys("patel");

        //type Email
        driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_Email")).sendKeys("nishatest20@gmail.com");

        //type Username
        driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_UserName")).sendKeys("nisha patel");

        driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);

        //Select country code
        Select drpCountry=new Select(driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_ddlCountry")));
        drpCountry.selectByVisibleText("India");

        //Select Your Role
        Select drpRole=new Select(driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_ddlRole")));
        drpRole.selectByVisibleText("Technical / developer");

        //Select Checkbox
        WebElement Checkbox=driver.findElement(By.id("ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_cbNewsletter"));
        Checkbox.click();


        //type password
        driver.findElement(By.xpath("//*[@id='ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_Password']")).sendKeys("Nisha123456");

        //type Confirmation
        driver.findElement(By.xpath("//*[@id='ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm_CreateUserStepContainer_ConfirmPassword']")).sendKeys("Nisha123456");

        //click on register
        driver.findElement(By.xpath("//*[@id='ctl00_ctl00_cph1_cph1_ctrlCustomerRegister_CreateUserForm___CustomNav0_StepNextButton']")).click();

        driver.quit();

        
    }
}
