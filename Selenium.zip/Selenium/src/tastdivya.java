import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

/**
 * Created by Suhagkumar on 12/07/2017.
 */
public class tastdivya
{
     public static void main(String[]args)
     {

            WebDriver driver=new FirefoxDriver();


            driver.get("https://reg.ebay.co.uk/reg/PartialReg?ru=https%3A%2F%2Fwww.ebay.co.uk%2F");
            driver.findElement(By.id("firstname")).sendKeys("Shree 420");
            driver.findElement(By.id("lastname")).sendKeys("Romeo");
            driver.findElement(By.id("email")).sendKeys("mohit_702@yahoo.co.in");
            driver.findElement(By.id("PASSWORD")).sendKeys("Inteha_ho_gayi");

            String expected="Register";
            String actual= driver.findElement(By.linkText("Register")).getText();

            Assert.assertEquals("Register","Register");

            driver.findElement(By.linkText("Register")).click();

            //(By.xpath("//*[@id=\"mainContent\"]/h2")).getText();

        }
}


