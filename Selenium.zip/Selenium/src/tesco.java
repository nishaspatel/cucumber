import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import java.util.concurrent.TimeUnit;

/**
 * Created by Suhagkumar on 10/07/2017.
 */
public class tesco
{
    public static void main(String args[])
    {
        WebDriver tesco=new FirefoxDriver();

        tesco.get("https://www.tesco.com/");

        tesco.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);

        tesco.manage().window().maximize();

        tesco.manage().deleteAllCookies();

        tesco.findElement(By.linkText("Sign in")).click();

        //Redirect user on Register page
        tesco.findElement(By.xpath(".//*[@id='register-cta']/span")).click();

        tesco.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);

        //select Title from dropdown
        Select dropdown=new Select(tesco.findElement(By.xpath(".//*[@id='title']")));
        dropdown.selectByVisibleText("Miss");

        //Type First Name
        tesco.findElement(By.xpath(".//*[@id='first-name']")).sendKeys("Nisha");

        //Type Last Name
        tesco.findElement(By.xpath(".//*[@id='last-name']")).sendKeys("phujknjk");

        //Type Phone number
        tesco.findElement(By.xpath(".//*[@id='phone-number']")).sendKeys("08945625236");

        //Type postcode
        tesco.findElement(By.xpath(".//*[@id='postcode']")).sendKeys("ha38hz");

        // Click on Find Address
        tesco.findElement(By.xpath(".//*[@id='address-field-set']/div/button")).click();

        //Select address according to Entered Postcode
        Select drpAddress=new Select(tesco.findElement(By.xpath(".//*[@id='address-dropdown']")));
        drpAddress.selectByVisibleText("2 Elmsleigh Avenue");

        //Type Email Address
        tesco.findElement(By.xpath(".//*[@id='username']")).sendKeys("nishatewaefd@gmail.com");


        //Type Password
        tesco.findElement(By.xpath(".//*[@id='password']")).sendKeys("Nisha124566");


        //Radio Button is by default selected
//                        WebElement radioBtn= tesco.findElement(By.className("component__radio-button-dot"));
//                        radioBtn.click();

        //Checkbox Selection
        WebElement oCheckbox=tesco.findElement(By.xpath(".//*[@id='marketing-field-set']/div/div[1]/label/span[2]"));
        oCheckbox.click();

        tesco.findElement(By.className("ui-component__button")).click();


        tesco.quit();

    }
}
